package application;

public class H1 {
	
	private final int id;
	private final String testo;
	
	H1(int id, String testo){
		this.id = id;
		this.testo = testo;
	}

	public int getId() {
		return id;
	}

	public String getTesto() {
		return testo;
	}
	
}
